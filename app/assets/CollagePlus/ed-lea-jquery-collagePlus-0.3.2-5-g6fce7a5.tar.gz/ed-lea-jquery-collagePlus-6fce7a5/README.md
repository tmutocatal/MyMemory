26th Sep 2013 - Temp Notice: I'm in the process of moving abroad so I'm a little slow on development of this. I'll be back shortly, it's not an abandoned project :)


##CollagePlus for jQuery

Create an image gallery like Google+ Albums or Flickr profile pages. 

Project home page: http://collageplus.edlea.com/


Example
-------
![Gallery Preview](https://raw.github.com/ed-lea/jquery-collagePlus/master/support/images/0.2.0-preview.png)

Try the [live example](http://collageplus.edlea.com/example.html "Live CollagePlus example") or play around with a [jsfiddle](http://jsfiddle.net/edlea/uZv3n/) version




For detailed usage instructions please visit http://collageplus.edlea.com/
